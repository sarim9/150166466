//
//  GameOverScene.swift
//  project_App
//
//  Created by Sarim on 05/01/2019.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import Foundation
import SpriteKit

class GameOverScene: SKScene{
    let restartLabel = SKLabelNode()
    
    
    override func didMove(to view: SKView) {
        let background = SKSpriteNode(imageNamed: "planeStart.jpg")
        background.size = self.size
        background.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
        background.zPosition = 0
        self.addChild(background)
        
        let gameOverLabel = SKLabelNode()
        gameOverLabel.text = "Game Over"
        gameOverLabel.fontName = "AvenirNext-Bold"
        gameOverLabel.fontSize = 150
        gameOverLabel.fontColor = UIColor.black
        gameOverLabel.position = CGPoint(x: self.size.width*0.6, y: self.size.height*0.7)
        gameOverLabel.zPosition = 1
        self.addChild(gameOverLabel)
        
        let scoreLabel = SKLabelNode()
        scoreLabel.text = "Score: \(gameScore)"
        scoreLabel.fontName = "AvenirNext-Bold"
        scoreLabel.fontSize = 80
        scoreLabel.fontColor = UIColor.black
        scoreLabel.position = CGPoint(x: self.size.width*0.6, y: self.size.height*0.3)
        scoreLabel.zPosition = 1
        self.addChild(scoreLabel)
        
        
        
        
        restartLabel.text = "Restart"
        restartLabel.fontSize = 100
        restartLabel.fontName = "AvenirNext-Bold"
        restartLabel.fontColor = UIColor.black
        restartLabel .position = CGPoint(x: self.size.width*0.6, y: self.size.height*0.48)
        restartLabel.zPosition = 1
        self.addChild(restartLabel)
        
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch: AnyObject in touches{
            let pointOfTouch = touch.location(in: self)
            
            if restartLabel.contains(pointOfTouch){
                let sceneToMoveTo = GameScene(size: self.size)
                sceneToMoveTo.scaleMode = self.scaleMode
                let myTransition = SKTransition.fade(withDuration: 0.5)
                self.view!.presentScene(sceneToMoveTo, transition: myTransition)
            }
        }
    }
}
