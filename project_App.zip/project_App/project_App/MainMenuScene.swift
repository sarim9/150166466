//
//  MainMenuScene.swift
//  project_App
//
//  Created by Sarim on 05/01/2019.
//  Copyright © 2019 Apple Inc. All rights reserved.
//


import Foundation
import SpriteKit

class MainMenuScene: SKScene{
    
    override func didMove(to view: SKView) {
        let background = SKSpriteNode(imageNamed: "planeStart.jpg")
        background.size = self.size
        background.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
        background.zPosition = 0
        background.name = "startGame"
        self.addChild(background)
        
        let gameName = SKLabelNode()
        gameName.text = "Crashy Plane"
        gameName.fontName = "AvenirNext-Bold"
        gameName.fontSize = 150
        gameName.fontColor = UIColor.red
        gameName.position = CGPoint(x: self.size.width*0.6, y: self.size.height*0.7)
        gameName.zPosition = 1
        self.addChild(gameName)
        
        let startGame = SKLabelNode()
        startGame.text = "Tap To Begin"
        startGame.fontName = "AvenirNext-Bold"
        startGame.fontSize = 100
        startGame.fontColor = UIColor.black
        startGame.position = CGPoint(x: self.size.width*0.6, y: self.size.height*0.48)
        startGame.zPosition = 1
        self.addChild(startGame)
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch: AnyObject in touches{
            let pointOfTouch = touch.location(in: self)
            let nodeITapped = atPoint(pointOfTouch)
            
            if nodeITapped.name == "startGame"{
                let sceneToMoveTo = GameScene(size: self.size)
                sceneToMoveTo.scaleMode = self.scaleMode
                let myTransition = SKTransition.fade(withDuration: 0.5)
                self.view!.presentScene(sceneToMoveTo, transition: myTransition)
            }
        }
    }
}
