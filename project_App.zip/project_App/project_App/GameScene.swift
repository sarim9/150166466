//
//  GameScene.swift
//  project_App
//
//  Created by Sarim on 05/01/2019.
//  Copyright © 2019 Apple Inc. All rights reserved.
//start


import SpriteKit
import GameplayKit

var gameScore = 0

var timer = Timer()


class GameScene: SKScene, SKPhysicsContactDelegate {
    
    private var plane = SKSpriteNode()
    private var planeFlyingFrames: [SKTexture] = []
    private var road = SKSpriteNode()
    private var roadMovingFrames: [SKTexture] = []
    private var dragon = SKSpriteNode()
    private var dragonFlutteringFrames: [SKTexture] = []
    private var cloud = SKSpriteNode()
    private var cloudMotionFrames: [SKTexture] = []
    
    var levelNumber = 0
    
    var backgroundMusic: SKAudioNode!
    
    var scoreLabel: SKLabelNode!
    
    func addScore(){
        gameScore += 2
        scoreLabel.text = "Score: \(gameScore)"
        if gameScore == 6 || gameScore == 12 || gameScore == 18{
            startNewLevel()
        }
    }
    
    enum gameState {
        case preGame // when the game state is before ethe start of the game
        case inGame // when the agme state is during the game
        case aftergame // when the game state is after the game
    }
    
    var currentGameState = gameState.preGame
    
    var tapTopStartLabel = SKLabelNode()
    
    struct PhysicsCategories{
        static let None : UInt32 = 0
        static let Plane : UInt32 = 0b1
        static let Bullet : UInt32 = 0b10
        static let Dragon : UInt32 = 0b100
        static let Coin : UInt32 = 0b1000
    }
    
    func random() -> CGFloat{
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    
    func random(min: CGFloat, max: CGFloat) -> CGFloat{
        return random() * (max - min) + min
    }
    
    func randomCoin() -> CGFloat{
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    
    func randomCoin(min: CGFloat, max: CGFloat) -> CGFloat{
        return randomCoin() * (max - min) + min
    }
    
    let gameArea: CGRect
    
    override init(size: CGSize){
        let maxAspectRatio: CGFloat = 16.0/9.0
        let playableWidth = size.height / maxAspectRatio
        let margin = (size.width - playableWidth) / 2
        gameArea = CGRect(x: margin, y: 0, width: playableWidth, height: size.height)
        super.init(size: size)
    }
    
    let coinSound = SKAction.playSoundFileNamed("coin.wav", waitForCompletion: false)
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func didMove(to view: SKView) {
    
        
        gameScore = 0
        
        self.physicsWorld.contactDelegate = self
        
        timer = Timer.scheduledTimer(timeInterval: 21, target: self, selector: #selector(timeFinished), userInfo: nil, repeats: false)

        
        scoreLabel = SKLabelNode(fontNamed: "Optima-ExtraBlack")
        scoreLabel.fontSize = 50
        scoreLabel.position = CGPoint(x: self.size.width/2, y: self.size.height * 0.9)
        scoreLabel.text = "SCORE: 0"
        scoreLabel.zPosition = 100
        scoreLabel.fontColor = UIColor.white
        addChild(scoreLabel)
        
        tapTopStartLabel = SKLabelNode(fontNamed: "Optima-ExtraBlack")
        tapTopStartLabel.fontSize = 100
        tapTopStartLabel.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
        tapTopStartLabel.text = "Tap To Begin!"
        tapTopStartLabel.zPosition = 1
        tapTopStartLabel.fontColor = UIColor.white
        addChild(tapTopStartLabel)
        
        let fadeInAction = SKAction.fadeIn(withDuration: 0.3)
        tapTopStartLabel.run(fadeInAction)
        
        if let musicURL = Bundle.main.url(forResource: "music", withExtension: "m4a") {
            backgroundMusic = SKAudioNode(url: musicURL)
            addChild(backgroundMusic)
        }
        backgroundMusic.run(SKAction())
        
        func buildPlane() {
            let planeAnimatedAtlas = SKTextureAtlas(named: "Images1")
            var flyingFrames: [SKTexture] = []
            
            let numImages = planeAnimatedAtlas.textureNames.count
            for i in 1...numImages {
                let planeTextureName = "plane\(i).png"
                flyingFrames.append(planeAnimatedAtlas.textureNamed(planeTextureName))
            }
            planeFlyingFrames = flyingFrames
            
            let firstFrameTexture = planeFlyingFrames[0]
            plane = SKSpriteNode(texture: firstFrameTexture)
            
            plane.setScale(3)
            plane.position = CGPoint(x: 0 - plane.size.width, y: self.size.height * 0.5)
            plane.zPosition = 2
            plane.physicsBody = SKPhysicsBody(rectangleOf: plane.size)
            plane.physicsBody?.usesPreciseCollisionDetection = true
            plane.physicsBody!.affectedByGravity = false
            plane.physicsBody?.allowsRotation = false
            plane.physicsBody!.categoryBitMask = PhysicsCategories.Plane
            plane.physicsBody!.collisionBitMask = PhysicsCategories.None
            plane.physicsBody!.collisionBitMask = PhysicsCategories.Dragon
            self.addChild(plane)
        }
        func animatePlane() {
            plane.run(SKAction.repeatForever(
                SKAction.animate(with: planeFlyingFrames,
                                 timePerFrame: 0.09)))
        }
        buildPlane()
        animatePlane()
        
        
        func buildRoad() {
            let roadAnimatedAtlas = SKTextureAtlas(named: "Images2")
            var movingFrames: [SKTexture] = []
            
            let numImages = roadAnimatedAtlas.textureNames.count
            for i in 1...numImages {
                let roadTextureName = "back\(i).png"
                movingFrames.append(roadAnimatedAtlas.textureNamed(roadTextureName))
            }
            roadMovingFrames = movingFrames
            
            let firstFrameTexture = roadMovingFrames[0]
            road = SKSpriteNode(texture: firstFrameTexture)
            
            road.size = self.size
            road.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
            road.zPosition = 0
            self.addChild(road)
        }
        
        func animateRoad() {
            road.run(SKAction.repeatForever(
                SKAction.animate(with: roadMovingFrames,
                                 timePerFrame: 0.3)))
        }
        buildRoad()
        animateRoad()
        
    
      
    }
    
    func startGame(){
        currentGameState = gameState.inGame
        
        let fadeOutAction = SKAction.fadeIn(withDuration: 0.5)
        let deleteAction = SKAction.removeFromParent()
        let deleteSequence = SKAction.sequence([fadeOutAction, deleteAction])
        tapTopStartLabel.run(deleteSequence)
        
        let movePlaneToScreen = SKAction.moveTo(x: self.size.width/4, duration: 0.5)
        let startLevelAction = SKAction.run(startNewLevel)
        let startLevelCoinAction = SKAction.run(startNewCoinLevel)
        let startGameSequence = SKAction.sequence([movePlaneToScreen, startLevelAction, startLevelCoinAction])
        plane.run(startGameSequence)
    }
    
    func startNewLevel(){
        
        levelNumber += 1
        if self.action(forKey: "spawningBirds") != nil{
            self.removeAction(forKey: "spawningBirds")
        }
        
        var levelDuration = TimeInterval()
        
        switch levelNumber {
        case 1: levelDuration = 2
        case 2: levelDuration = 1.7
        case 3: levelDuration = 1.5
        case 4: levelDuration = 1.4
        default:
            levelDuration = 1.4
            print ("cannot find level info")
        }
        let spawn = SKAction.run(spawnDragon)
        let waitToSpawn = SKAction.wait(forDuration: levelDuration)
        let spawnSequence = SKAction.sequence([spawn, waitToSpawn])
        let spawnForever = SKAction.repeatForever(spawnSequence)
        self.run(spawnForever, withKey: "spawningBirds")
        
    }
    func startNewCoinLevel(){
        
        let spawnCoinAction = SKAction.run(spawnCoin)
        let waitToSpawnCoin = SKAction.wait(forDuration: 5)
        let spawnCoinSequence = SKAction.sequence([spawnCoinAction, waitToSpawnCoin])
        let spawnCoinForever = SKAction.repeatForever(spawnCoinSequence)
        self.run(spawnCoinForever)
    }
    
    func fireBullet() {
        
        let bullet = SKSpriteNode(imageNamed: "bullet.png")
        bullet.name = "Bullet"
        bullet.setScale(0.1)
        bullet.position = plane.position
        bullet.zPosition = 1
        bullet.physicsBody = SKPhysicsBody(rectangleOf: bullet.size)
        bullet.physicsBody!.affectedByGravity = false
        bullet.physicsBody?.usesPreciseCollisionDetection = true
        bullet.physicsBody?.allowsRotation = false
        bullet.physicsBody!.categoryBitMask = PhysicsCategories.Bullet
        bullet.physicsBody!.collisionBitMask = PhysicsCategories.None
        bullet.physicsBody!.collisionBitMask = PhysicsCategories.Dragon
        self.addChild(bullet)
        
        let moveBullet = SKAction.moveTo(x: self.size.width + bullet.size.width, duration: 1)
        let deleteBullet = SKAction.removeFromParent()
        let bulletSound = SKAction.playSoundFileNamed("gunshot.mp3", waitForCompletion: false)
        let bulletSequence = SKAction.sequence([bulletSound, moveBullet, deleteBullet])
        bullet.run(bulletSequence)
    }
    
    func spawnDragon(){
        
        let randomYStart = random(min: gameArea.minY, max: gameArea.maxY)
        let randomYEnd = random(min: gameArea.minY, max: gameArea.maxY)
        
        let startPoint = CGPoint(x: self.size.width * 1.4, y: randomYStart )
        let endPoint = CGPoint(x: 0 - dragon.size.width, y: randomYEnd)
        
        func buildDragon() {
            let dragonAnimatedAtlas = SKTextureAtlas(named: "Images3")
            var flutteringFrames: [SKTexture] = []
            
            let numImages = dragonAnimatedAtlas.textureNames.count
            for i in 1...numImages {
                let dragonTextureName = "dragon\(i).png"
                flutteringFrames.append(dragonAnimatedAtlas.textureNamed(dragonTextureName))
            }
            dragonFlutteringFrames = flutteringFrames
            let firstFrameTexture = dragonFlutteringFrames[0]
            dragon = SKSpriteNode(texture: firstFrameTexture)
            dragon.name = "Bird"
            dragon.setScale(2)
            dragon.zPosition = 2
            dragon.position = startPoint
            dragon.physicsBody = SKPhysicsBody(rectangleOf: dragon.size)
            dragon.physicsBody!.affectedByGravity = false
            dragon.physicsBody?.usesPreciseCollisionDetection = true
            dragon.physicsBody!.categoryBitMask = PhysicsCategories.Dragon
            dragon.physicsBody!.collisionBitMask = PhysicsCategories.None
            dragon.physicsBody!.contactTestBitMask = PhysicsCategories.Plane  | PhysicsCategories.Bullet
            self.addChild(dragon)
        }
        func animateDragon() {
            dragon.run(SKAction.repeatForever(
                SKAction.animate(with: dragonFlutteringFrames,
                                 timePerFrame: 0.05)))
        }
        buildDragon()
        animateDragon()
        
        let movedragon = SKAction.move(to: endPoint, duration: 3)
        let deletedragon = SKAction.removeFromParent()
        let dragonSequence = SKAction.sequence([movedragon, deletedragon])
        dragon.run(dragonSequence)
    }
    
    func spawnCoin(){
        let randomYStart = random(min: gameArea.minY, max: gameArea.maxY)
        let randomYEnd = random(min: gameArea.minY, max: gameArea.maxY)
        
        let startPoint = CGPoint(x: self.size.width * 1.4, y: randomYStart )
        let endPoint = CGPoint(x: self.size.height * 0.2, y: randomYEnd)
        
        let coin = SKSpriteNode(imageNamed: "coin.png")
        coin.setScale(1)
        coin.name = "Coin"
        coin.zPosition = 2
        coin.position = startPoint
        coin.physicsBody = SKPhysicsBody(rectangleOf: coin.size)
        coin.physicsBody!.affectedByGravity = false
        coin.physicsBody?.usesPreciseCollisionDetection = true
        coin.physicsBody!.categoryBitMask = PhysicsCategories.Coin
        coin.physicsBody!.collisionBitMask = PhysicsCategories.None
        coin.physicsBody!.contactTestBitMask = PhysicsCategories.Plane
        self.addChild(coin)
        
        
        let moveCoin = SKAction.move(to: endPoint, duration: 4)
        let deleteCoin = SKAction.removeFromParent()
        let CoinSequence = SKAction.sequence([moveCoin, deleteCoin])
        coin.run(CoinSequence)
        
    }
    
    func didBegin(_ contact: SKPhysicsContact){
        
        var body1 = SKPhysicsBody()
        var body2 = SKPhysicsBody()
        
        if contact.bodyA.contactTestBitMask < contact.bodyB.categoryBitMask{
            body1 = contact.bodyA
            body2 = contact.bodyB
        }
        else{
            body1 = contact.bodyB
            body1 = contact.bodyA
        }
        if body1.categoryBitMask == PhysicsCategories.Plane && body2.categoryBitMask == PhysicsCategories.Dragon{
            //if plane has hit the bord
            
            if body1.node != nil {
                spawnExplosion(spawnPosition: body1.node!.position)
            }
            
            if body2.node != nil {
                spawnExplosion(spawnPosition: body2.node!.position)
            }
            
            body1.node?.removeFromParent()
            body2.node?.removeFromParent()
            
            runGameOver()
            
        }
        if body1.categoryBitMask == PhysicsCategories.Bullet && body2.categoryBitMask == PhysicsCategories.Dragon && (body2.node?.position.x)! < self.size.width{
            //if the bullet has hit the bird
            body1.node!.removeFromParent()
            body2.node!.removeFromParent()
            
            addScore()
        }
        if body1.categoryBitMask == PhysicsCategories.Plane && body2.categoryBitMask == PhysicsCategories.Coin{
            //if plane has hit the bord
            body2.node?.removeFromParent()
            run(coinSound)
            addScore()
        }
    }
    
    func spawnExplosion(spawnPosition: CGPoint) {
        let explosion = SKSpriteNode(imageNamed: "explosion.png")
        explosion.position = spawnPosition
        explosion.zPosition = 3
        self.addChild(explosion)
        
        let scaleIn = SKAction.scale(to: 1, duration: 0.1)
        let fadeOut = SKAction.fadeOut(withDuration: 0.1)
        let delete = SKAction.removeFromParent()
        let sound = SKAction.playSoundFileNamed("explosion.wav", waitForCompletion: false)
        let explosionSequence = SKAction.sequence([sound, scaleIn, fadeOut, delete])
        
        if currentGameState == gameState.inGame{
            explosion.run(explosionSequence)
        }
    }
    
    func runGameOver(){
        currentGameState = gameState.aftergame
        
        self.removeAllActions()
        self.enumerateChildNodes(withName: "Bullet"){
            bullet, stop in
            bullet.removeAllActions()
        }
        self.enumerateChildNodes(withName: "Bird"){
            bird, stop in
            bird.removeAllActions()
        }
        
        let changeSceneAction = SKAction.run(changeScene)
        let waitToChangeScene = SKAction.wait(forDuration: 1)
        let changeSceneSequence = SKAction.sequence([waitToChangeScene, changeSceneAction])
        self.run(changeSceneSequence )
    }
    
    @objc func timeFinished(){
        let sceneToMoveTo = GameOverScene(size: self.size)
        sceneToMoveTo.scaleMode = self.scaleMode
        let myTransition = SKTransition.fade(withDuration: 0.5)
        self.view?.presentScene(sceneToMoveTo, transition: myTransition)
    }
        func changeScene(){
        let sceneToMoveTo = GameOverScene(size: self.size)
        sceneToMoveTo.scaleMode = self.scaleMode
        let myTransition = SKTransition.fade(withDuration: 0.5)
        self.view?.presentScene(sceneToMoveTo, transition: myTransition)
    
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if currentGameState == gameState.preGame{
            startGame()
        }
        else if currentGameState == gameState.inGame{
            fireBullet()
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch: AnyObject in touches{
            let pointOfTouch = touch.location(in: self)
            
            let previousPointOfTouch = touch.previousLocation(in: self)
            
            if currentGameState  == gameState.inGame{
                let amountDraggedX = pointOfTouch.x - previousPointOfTouch.x
                let amountDraggedY = pointOfTouch.y - previousPointOfTouch.y
                
                plane.position.x += amountDraggedX
                plane.position.y += amountDraggedY
            }
        }
    }
}
//if plane.position.x > gameArea.maxX  {

//plane.position.x = gameArea.maxX

//}
//if plane.position.x > gameArea.minX{

//    plane.position.x = gameArea.minX

//}
//if plane.position.y > gameArea.maxY  {

//    plane.position.y = gameArea.maxY

//}
//if plane.position.y > gameArea.minY{

//    plane.position.y = gameArea.minY

//}

